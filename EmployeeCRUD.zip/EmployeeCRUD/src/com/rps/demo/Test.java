package com.rps.demo;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {
	public static void main(String[] args) {
		Session s = new Configuration().configure().buildSessionFactory().openSession();

		 Transaction t = s.beginTransaction();
//		//Employee Insertion
//		 Employee emp = new Employee("suresh", 39000, "hyd");
//		 s.save(emp);//ORM

		// fetch employee get and update
		// Employee emp = s.get(Employee.class, 1);// hql

		// System.out.println(emp.getEmpName());

		// emp.setEmpName("Yash");
		// s.update(emp);// ORM
		//s.delete(emp);

		// HQL,SQL


//
//		Query q = s.createQuery("select p.empId from Employee p");
//		List<Integer> list = q.list();
//		Iterator<Integer> itr = list.iterator();
//		while (itr.hasNext()) {
//			System.out.println(itr.next());
//		}
//
		Query q1 = s.createQuery("update Employee e set e.empSal=e.empSal+5000 where e.empSal<50000");

		q1.executeUpdate();
		Query<Employee> query = s.createQuery("select e from Employee e", Employee.class);

		List<Employee> emps = query.getResultList();

		for (Employee emp : emps) {
			System.out.println(emp);
		}
		 t.commit();
		s.close();

		// HQL-hibernate query lanaguage

	}
}
