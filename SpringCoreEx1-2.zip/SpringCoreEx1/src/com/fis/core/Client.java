package com.fis.core;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
	public static void main(String[] args) {

		Resource resource = new ClassPathResource("springconfig.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		Employee1 emp= (Employee1) factory.getBean("employee");
		System.out.println(emp);
		Employee1 emp2= (Employee1) factory.getBean("employee");
		System.out.println(emp2);
		Employee1 emp1= (Employee1) factory.getBean("emp");
		System.out.println(emp1);
	}
}
