package com.fis.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.fis.core")
public class Client {
	public static void main(String[] args) {

//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);

//		ApplicationContext factory=new ClassPathXmlApplicationContext("springconfig.xml");

		ApplicationContext factory = new AnnotationConfigApplicationContext(Client.class);

//		Employee emp = (Employee) factory.getBean("employee");
//		System.out.println(emp);
		Employee emp1 = factory.getBean(Employee.class);
		System.out.println(emp1);
		System.out.println(emp1.getAddress());
	}
}
