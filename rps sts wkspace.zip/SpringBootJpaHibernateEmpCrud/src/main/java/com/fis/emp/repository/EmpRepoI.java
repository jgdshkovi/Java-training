package com.fis.emp.repository;

import java.util.List;
import java.util.Optional;

import com.fis.emp.entity.Employee;


public interface EmpRepoI {

	public abstract Employee addEmployee(Employee employee);
	
	public abstract Employee updateEmployee(Employee employee);
	
	public List<Employee> findEmployeeByName(String name);
	
	public abstract void removeEmployee(int eid);
	
	public abstract Optional<Employee> findEmployeeById(int eid);
	
	public abstract List<Employee>  listEmployee();
	
	public List<Employee> getAllInBetween(int initialSal, int salary);
	
}
