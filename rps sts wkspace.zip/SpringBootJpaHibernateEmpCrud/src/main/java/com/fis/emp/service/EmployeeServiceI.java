package com.fis.emp.service;

import java.util.List;
import java.util.Optional;

import com.fis.emp.entity.Employee;

public interface EmployeeServiceI {

	public abstract Employee addEmployee(Employee employee);

	public abstract Employee updateEmployee(Employee employee);

	public List<Employee> findEmployeeByName(String name);

	public abstract void removeEmployee(Employee employee);

	public abstract Optional<Employee> findEmployeeById(int eid);

	public abstract List<Employee> listEmployee();

	public List<Employee> getAllInBetween(int initialSal, int salary);
}
