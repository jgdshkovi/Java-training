package com.fis.emp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.fis.emp.service.EmployeeServiceI;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeServiceI service;
}
