package com.fis.emp.service;

import java.util.List;
import java.util.Optional;

import com.fis.emp.entity.Employee;

public class EmployeeServiceImpl implements EmployeeServiceI{

	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> findEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Optional<Employee> findEmployeeById(int eid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> listEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> getAllInBetween(int initialSal, int salary) {
		// TODO Auto-generated method stub
		return null;
	}


}
