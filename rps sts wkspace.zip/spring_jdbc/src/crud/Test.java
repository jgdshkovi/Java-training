package crud;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {
	public static void main(String[] args) {

		Resource r = new ClassPathResource("applicationConfig.xml");
		BeanFactory factory = new XmlBeanFactory(r);

		EmployeeDao dao = (EmployeeDao) factory.getBean("edao");

		// Insert Employee
		Employee emp = new Employee(225, "naresh", 45000);

		System.out.println("Inserted : " + dao.insertEmployee(emp));
		// Update Employee
		System.out.println("Updated  :  " + dao.update(new Employee(225, "somesh", 35000)));

		// Fetch Employees
		System.out.println("Fetching All Employees  :  ");
		dao.getEmployees().stream().forEach(System.out::println);

		// Delete Employee
		System.out.println("Deleted : " + dao.deleteEmployee(225));

	}

}
