package jd;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDao {
	JdbcTemplate template;

	public EmployeeDao(JdbcTemplate template) {
		this.template = template;
	}

	public int update(Employee e) {
		String query = "update emp set name=?,sal=? where id=?";
		
		return template.update(query, e.getName(), e.getSalary(), e.getId());
		//execute,executeUpdate,executeQuery
		//execute,update,query
	}

}