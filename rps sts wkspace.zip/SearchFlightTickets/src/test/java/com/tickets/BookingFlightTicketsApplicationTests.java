package com.tickets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingFlightTicketsApplicationTests {

	@Test
	void contextLoads() {
	}

}
