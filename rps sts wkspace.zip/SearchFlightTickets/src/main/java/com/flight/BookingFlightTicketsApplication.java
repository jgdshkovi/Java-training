package com.flight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingFlightTicketsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingFlightTicketsApplication.class, args);
	}

}
