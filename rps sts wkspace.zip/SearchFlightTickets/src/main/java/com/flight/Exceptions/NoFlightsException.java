package com.flight.Exceptions;

public class NoFlightsException extends RuntimeException{


	public NoFlightsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
