package com.flight.controller;

public class flightController {

}

package com.flight.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.models.Flight;
import com.flight.models.FlightDTO;
import com.flight.service.SearchService;

@RestController
public class flightController {
	@Autowired
	private flightServices service;
	
	@GetMapping("/flights")
	public ResponseEntity<flightDTO> getflights(){
		List<flight> list= service.getflights();
		flightDTO dto=new flightDTO();
		dto.setList(list);
		return new ResponseEntity<flightDTO>(dto,HttpStatus.OK);
		
	}
}
