package com.flight.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.Exceptions.NoFlightsException;
import com.flight.dao.FlightDao;
import com.flight.models.Flight;

@Service
public class SearchService {
	@Autowired
	private FlightDao dao;
	
	public List<Flight> getFlights(){
	
		List<Flight> list=dao.findAll();
		if(list.isEmpty()) {
			throw new NoFlightsException("No Flights Tickets found");
		}
		else return list;
	}
	
	
}
