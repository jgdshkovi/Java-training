package com.flight.models;
import java.util.List;

public class FlightDTO {

	private List<Flight> list;

	@Override
	public String toString() {
		return "flightDTO [list=" + list + "]";
	}

	public List<Flight> getList() {
		return list;
	}

	public void setList(List<Flight> list) {
		this.list = list;
	}
}
