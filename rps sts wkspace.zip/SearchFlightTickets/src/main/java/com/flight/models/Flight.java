package com.flight.models;

public class Flight {

}
