package com.flight.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flight.models.Flight;

public interface FlightDao extends JpaRepository<Flight, Integer> {

//	public List<Product> getflights();
}
