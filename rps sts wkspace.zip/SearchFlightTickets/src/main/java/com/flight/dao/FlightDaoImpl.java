package com.flight.dao;
/*
 * package com.tickets.dao;
 * 
 * public class FlightsDaoImpl implements FlightsDao {
 * 
 * }
 */