package com.student.service;

import java.util.List;

import javax.transaction.Transactional;

import com.student.dao.StudentDao;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.entity.Student;

@Service("StudentService")
//@Transactional
public class StudentServiceImpl implements StudentService {
	
	static Logger log =Logger.getLogger(StudentServiceImpl.class);
	
	@Autowired
	private StudentDao dao;

	@Override
	public Student addStudent(Student emp) {
		//dao.saveAll(List)
		log.info("Service Layer-Entry-Add Student");
		if(emp.getSname().isEmpty()) {
			log.warn("WARN: Student name shouldn't be empty");
		}
		log.info("Service Layer-Exit-Add Student");
		return dao.save(emp);// persist()
		
	}

	@Override
	public Student updateStudent(Student emp) {
//		return dao.save(emp);
		log.info("Service Layer-Entry-Update Student");
		if(emp.getSname().isEmpty()) {
			log.warn("WARN: Student name shouldn't be empty");
		}
		log.info("Service Layer-Exit-Update Student");
		return dao.save(emp);
	}

	@Override
	public void removeStudent(int empId) {
		dao.deleteById(empId);
	}

	@Override
	public List<Student> findStudentByName(String sname) {

		log.info("Service Layer-Entry-Find Student");
		if(sname.isEmpty()) {
			log.warn("WARN: Student name shouldn't be empty");
		}
		log.info("Service Layer-Exit-Find Student");
		return dao.findBySname(sname);//DSL
	}

	@Override
	public List<Student> listStudent() {

		log.info("Service Layer-Entry-List Student");
		List<Student> l1 = dao.findAll();
//		log.info(l1.size()+" details found");
		log.info("Service Layer-Exit-List Student");
		return l1;
	}

	@Override
	public List<Student> getAllInBetween(int initialAge, int age) {
		log.info("Service Layer-Entry-GetAllIN BTWn Student");
		log.info("Service Layer-Exit-GetAllIN BTWn Student");
		return dao.getAllInBetween(initialAge, age);
	}
}