package com.student.service;

import java.util.List;
//import java.util.Optional;

import com.student.entity.Student;

public interface StudentService {

	public abstract Student addStudent(Student Student);

	public abstract Student updateStudent(Student Student);

	public List<Student> findStudentByName(String ename);

	public abstract void removeStudent(int empId);

	public List<Student> getAllInBetween(int initialAge, int age);

	public List<Student> listStudent();
	
}
