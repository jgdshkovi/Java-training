package com.student.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.student.entity.Student;

public interface StudentDao extends JpaRepository<Student, Integer> {//springbootdatajpa
	
	
	
@Query("select s from Student s where s.sage between ?1 and ?2")
public List<Student> getAllInBetween(int initialAge,int age);

public List<Student> findBySname(String sname);
//
//public List<Employee> findByEsalBetween(Integer initialSal,Integer salary);
//
//
//public List<Employee> findByEname(String ename );
//public List<Employee> findByCity(String cit );
}
//
//fetch all student byname
//fetch students by marks inbetween
//....