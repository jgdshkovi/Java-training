package com.student.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.transaction.Transactional;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
//import com.sun.istack.NotNull;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

@Entity
@Table(name = "stu_info")
//@Transactional
public class Student {
	@Id
	@GeneratedValue
	@Column(length = 12)
	private int sid;
	
	@Column(length = 12)
	@NotBlank(message = "Name is mandatory")
	@NotNull(message="name as null not allowed ")
	private String sname;
	
	@Positive(message="Enter valid age")
	@Min(value=10,message="Age must be above 10")
	@Max(value=20, message="Age must be below 20")
	private Integer sage;
	
	public Student(int sid, String sname, Integer sage) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sage = sage;
	}
	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public Integer getSage() {
		return sage;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", sage=" + sage + "]";
	}
	public Student() {
		super();
	}
	public void setSage(Integer sage) {
		this.sage = sage;
	}
	
	

}
