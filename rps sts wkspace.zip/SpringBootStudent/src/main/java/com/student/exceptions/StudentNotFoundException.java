package com.student.exceptions;

import org.apache.log4j.Logger;

public class StudentNotFoundException extends Exception {
	
	static Logger log = Logger.getLogger(StudentNotFoundException.class.getClass());
	
	public StudentNotFoundException(String message) {
		super(message);
		log.info(message);
	}
}
