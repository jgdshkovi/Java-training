package com.student;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.student.entity.Student;
import com.student.service.StudentService;

@SpringBootTest
class SpringBootStudentApplicationTests {

	Logger log = Logger.getLogger(SpringBootStudentApplicationTests.class);

	@Autowired
	StudentService service;
	
	@Test
	public void addStudentTest() {
		
		Student st = new Student(10,"Jaga",19);
		
		List<Student> slist = service.listStudent();
		int count = slist.size();
		
		Student st1 = service.addStudent(st);
		
		List<Student> slist1 = service.listStudent();
		int count1 = slist1.size();
		
		assertEquals(count+1,count1);
	}

}
