package com.student.service1;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;

import com.student.dao.StudentDao;
import com.student.entity.Student;
import com.student.service.StudentService;
import com.student.service.StudentServiceImpl;

@Transactional
public class AddStuTest {

	static Logger log = Logger.getLogger(AddStudentTest.class);

	@Autowired
	StudentService service;
	@Autowired
	private StudentDao dao;

//	@Test
	@DisplayName("Test - Add Student - Successful")
	public void correctStudentInsertion() {

		log.info("blah");
		
		Student st = new Student(11, "Jaga", 15);
//		dao.save(st);
//		List<Student> slist = service.listStudent();
//		int count1 = slist.size();
		
		Student s = service.addStudent(st);
		
		assertEquals(s.getSid(), s.getSid());
		
//		int count2 = service.listStudent().size();
//		if(count1+1==count2)
//			assert(true);
//		else
//			assert(false);
		
//		try {
//			List<Student> list = (List<Student>) ss.addStudent(st);
//			assertEquals(1, list.size());
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		assert (true);
	}

//	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
