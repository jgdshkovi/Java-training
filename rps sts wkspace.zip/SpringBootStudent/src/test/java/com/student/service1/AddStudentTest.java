package com.student.service1;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.student.entity.Student;
import com.student.service.StudentService;

public class AddStudentTest {

	static Logger log = Logger.getLogger(AddStudentTest.class.getClass());
	
	@Autowired
	StudentService service;
	
//	@Test
	@DisplayName("Test - Add Student - Successful")
	public void correctStudentInsertion() {
		
		log.info("blah");
		int sid=12;
		String sname="Jaga";
		int sage=22;
		Student st = new Student(sid, sname, sage);
//		List<Student> slist = service.listStudent();
//		int count1 = slist.size();
		Student s = service.addStudent(st);
		int count2 = service.listStudent().size();
		if(count2!=0)
			assert(true);
		else
			assert(false);
		
	}
}
