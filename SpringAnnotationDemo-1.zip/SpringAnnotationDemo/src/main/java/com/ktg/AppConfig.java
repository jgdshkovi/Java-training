package com.ktg;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration// @Component
@ComponentScan(basePackages = { "com.ktg" })
public class AppConfig {
	@Bean //user defined spring @Component  <bean>
	public Address getAddress() {
		Address address = new Address(123, "hyderabad");
		address.setHno(11);
		address.setCity("hyd");
		return address;
	}
	@Bean(name ="emp")
	public Employee getEmp() {
		Employee employee = new Employee();
		employee.setEid(123);
		employee.setEname("suresh");
		employee.setAdd(getAddress());
		employee.setTadd(getTAddress());
		return employee;
	}
	@Bean
	public TAddress getTAddress() {
		TAddress address = new TAddress();
		address.setHno(11);
		address.setColony("abccolony");
		address.setVillage("xyz");
		return address;
	}
}
