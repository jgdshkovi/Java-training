package com.vehicleloanapplication.service;

 

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.vehicleloanapplication.dao.UserRegisterJPARepository;
import com.vehicleloanapplication.exceptions.DuplicateRecordException;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.AdminEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.LogoutService;

 

//LOGOUT IMPLEMENTATION 
@Service
public class LogoutServiceImpl implements LogoutService {

 


    @Autowired
    private UserRegisterJPARepository userRegisterRepo;
    // USED TO LOGOUT
        @Override
        public UserRegistrationEntity logout(UserRegistrationEntity userbasic)throws RecordNotFoundException {
            // TODO Auto-generated method stub
            Optional<UserRegistrationEntity> userbasics = userRegisterRepo.findById(userbasic.getEmail());
            if (!userbasics.isPresent()) 
            {
                return null;
            } else
                return userbasics.get();
        }
}