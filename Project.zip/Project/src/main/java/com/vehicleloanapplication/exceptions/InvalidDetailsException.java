package com.vehicleloanapplication.exceptions;

public class InvalidDetailsException extends Exception {
	public InvalidDetailsException(String msg) {
		super(msg);
	}
}
