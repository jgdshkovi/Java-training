package com.vehicleLoanApplication.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.vehicleloanapplication.dao.AdminJPARepository;
import com.vehicleloanapplication.dao.UserRegisterJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.exceptions.RegistrationException;
import com.vehicleloanapplication.model.AdminEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.LoginDtoService;
@SpringBootTest
public class AdminSignInTest {
	@MockBean//proxy
	AdminJPARepository adminRepo;
	
     @Autowired  
     LoginDtoService loginService;
     
     @Test    
     @DisplayName("Admin Signin - If Invalid Details Found")
     public void invalidDetailsFound()  
     {  
    	 AdminEntity admin=null;
    	 AdminEntity retadmin = null;
    	 Mockito.doReturn(admin).when(adminRepo).findById("admin@gmail.com");
    	 try {
    		
				retadmin=loginService.authenticateAdmin("admin@gmail.com", "password");
			
    	 }    
    	 catch(Exception e)
    	 {
    		 assertNull(retadmin);
    	 }
     }
     @Test
     @DisplayName("Admin Signin - If Password Doest matches")
     public void invalidPasswordFound()
     {
    	 AdminEntity admin=new AdminEntity("admin@gmail.com","admin","password");
    	 Mockito.doReturn(Optional.of(admin)).when(adminRepo).findById("admin@gmail.com");
    	 try {
    		 AdminEntity retadmin=loginService.authenticateAdmin("admin@gmail.com", "pass");
    	 }
    	 catch(RegistrationException | RecordNotFoundException e)
    	 {
    		 assertEquals(e.getMessage(),"Password does not match");
    	 }
     }
     @Test
     @DisplayName("Admin Signin - If Record Found")
     public void correctDetailsFound()
     {
    	 AdminEntity admin=new AdminEntity("admin@gmail.com","admin","password");
    	 Mockito.doReturn(Optional.of(admin)).when(adminRepo).findById("admin@gmail.com");
    	 try {
    		 AdminEntity retadmin=loginService.authenticateAdmin("admin@gmail.com", "password");assertSame(admin,retadmin);
    	 }
    	 catch(RegistrationException | RecordNotFoundException e)
    	 {
    		 e.printStackTrace();
    	 }
     }
    
	
}
