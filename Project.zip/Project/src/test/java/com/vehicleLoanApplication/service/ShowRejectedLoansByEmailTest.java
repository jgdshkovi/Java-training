package com.vehicleLoanApplication.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.vehicleloanapplication.dao.LoanApplicationJPARepository;
import com.vehicleloanapplication.dao.UserRegisterJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.LoanApplicationEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.LoanApplicationServiceImpl;

@SpringBootTest
public class ShowRejectedLoansByEmailTest {

	@BeforeEach
	public void setup() {

	}

	@MockBean
	UserRegisterJPARepository userRepo;

	@MockBean
	LoanApplicationJPARepository loanRepo;

	@Autowired
	LoanApplicationServiceImpl loanService;

//Successfully shown rejected loan applications by email
	@Test
	@DisplayName("Show Rejected Loan Application By Email- successful")
	public void RejectedLoanApplicationByEmailSuccessfull() throws RecordNotFoundException {
		String email = "hello@gmail.com";

		List<LoanApplicationEntity> list = new ArrayList<LoanApplicationEntity>();

		UserDetailsEntity user = new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu", "Chennai", "600073",
				"Full time", 5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");

		UserRegistrationEntity userRegister = new UserRegistrationEntity("hello@gmail.com", 21, "M", "9856435672",
				"abc", "hello", user);

		LoanApplicationEntity loan = new LoanApplicationEntity("12ht45", 200000.0, 10, 5.0, 5000000, LocalDate.now(),
				"Rejected", "Mercedes", "red", "cls", 4, 5000000.0, 6000000, user);

		LoanApplicationEntity loan1 = new LoanApplicationEntity("12ht46", 200000.0, 10, 5.0, 5000000, LocalDate.now(),
				"Rejected", "Mercedes", "red", "cls", 4, 5000000.0, 6000000, user);

		Mockito.when(loanRepo.showAllRejectedLoansByEmail(email)).thenReturn(Arrays.asList(loan, loan1));
		list = loanService.showRejectedLoansByEmail(email);
		assertEquals(list.size(), 2);

	}

//No rejected loan applications found
	@Test
	@DisplayName("Show Rejected Loan Application By Email- no loan applications found")
	public void noRejectedLoanApplicationsFound() {
		String email = "hello@gmail.com";

		List<LoanApplicationEntity> list = new ArrayList<LoanApplicationEntity>();

		List<LoanApplicationEntity> returnedList = new ArrayList<LoanApplicationEntity>();

		UserDetailsEntity user = new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu", "Chennai", "600073",
				"Full time", 5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");

		UserRegistrationEntity userRegister = new UserRegistrationEntity("hello@gmail.com", 21, "M", "9856435672",
				"abc", "hello", user);

		Mockito.when(userRepo.saveAndFlush(userRegister)).thenReturn(userRegister);

		try {
			Mockito.when(loanRepo.showAllRejectedLoansByEmail(email)).thenReturn(list);
			returnedList = loanService.showRejectedLoansByEmail(email);
			assertEquals(list, returnedList);
		} catch (RecordNotFoundException e) {
			// TODO Auto-generated catch block

			assertEquals(e.getMessage(), "No Rejected loans found");
		}

	}

//Email not entered
	@Test
	@DisplayName("Show Rejected Loan Applications By Email- no email entered")
	public void nullEmailEntered() {
		String email = null;

		List<LoanApplicationEntity> list = new ArrayList<LoanApplicationEntity>();

		List<LoanApplicationEntity> returnedList = new ArrayList<LoanApplicationEntity>();

		UserDetailsEntity user = new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu", "Chennai", "600073",
				"Full time", 5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");

		UserRegistrationEntity userRegister = new UserRegistrationEntity(null, 21, "M", "9856435672", "abc", "hello",
				user);

		try {
			Mockito.when(loanRepo.showAllRejectedLoansByEmail(email)).thenReturn(list);
			returnedList = loanService.showRejectedLoansByEmail(email);
			assertEquals(list, returnedList);
		} catch (Exception e) {
			assertNotNull(e.getMessage());
		}

	}
}
