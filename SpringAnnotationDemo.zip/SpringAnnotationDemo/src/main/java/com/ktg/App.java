package com.ktg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan(basePackages = { "com.ktg" })
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
		Employee emp = context.getBean("emp", Employee.class);
		System.out.println(emp);
		emp.display();
	}
}
//layered architecture @component /@Entity   @Service @Repository @Controller @Bean 

//@Autowired,@Component ,@Configration,@Value,@ComponentScan,@Scope,@Qualifier

			//@Service  @Repository @Qualifier
//Beanfactory->the implementations use lazy loading, which means that beans are only instantiating when we directly calling them through the getBean() method.
//ApplicationContext-->It uses eager loading, so every bean instantiate after the ApplicationContext is started up.