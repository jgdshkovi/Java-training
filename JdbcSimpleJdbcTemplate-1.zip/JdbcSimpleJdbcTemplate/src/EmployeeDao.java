import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowCallbackHandler;

public class EmployeeDao {
	JdbcTemplate template;

	public EmployeeDao(JdbcTemplate template) {
		this.template = template;
	}

	public int insertEmployee(Employee e) {
		String query = "insert into employee values(?,?,?)";

		return template.update(query, e.getId(), e.getName(), e.getSalary());

	}

	public int update(Employee e) {
		String query = "update employee set ename=?,esal=? where eid=?";

		return template.update(query, e.getName(), e.getSalary(), e.getId());

	}

	public int deleteEmployee(int id) {
		String query = "delete employee where eid=?";

		return template.update(query, id);
	}

	public List<Employee> getEmployees() {
		return template.query("select * from employee", new ResultSetExtractor<List<Employee>>() {
			public List<Employee> extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<Employee> list = new ArrayList<Employee>();
				while (rs.next()) {
					Employee e = new Employee();
					e.setId(rs.getInt(1));
					e.setName(rs.getString(2));
					e.setSalary(rs.getInt(3));
					list.add(e);
				}
				return list;
			}
		});
	}
}