package com.rps.employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rps.employee.dao.EmployeeDAO;
import com.rps.employee.model.Employee;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAO employeeDAO;

	public void persistEmployee(Employee employee) {
		employeeDAO.persistEmployee(employee);

	}

	public void updateEmployee(Employee employee) {
		employeeDAO.updateEmployee(employee);

	}

	public Employee findEmployeeById(String id) {
		return employeeDAO.findEmployeeById(id);
	}

	public void deleteEmployee(Employee employee) {
		employeeDAO.deleteEmployee(employee);

	}

}
